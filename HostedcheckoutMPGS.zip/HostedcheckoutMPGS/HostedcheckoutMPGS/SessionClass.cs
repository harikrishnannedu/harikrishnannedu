﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HostedcheckoutMPGS
{
    public static class SessionClass
    {
        public static string SessionId;

        public static string OrderId;

        public static string TransactionId;
        public static string amount;
        public static string currency;

        public static byte[] ConvertToBytes(string plainData)
        {
            return Encoding.ASCII.GetBytes(plainData);
        }

        public static string ConvertToString(byte[] byteData)
        {
            return Encoding.ASCII.GetString(byteData);
        }

    }
}
