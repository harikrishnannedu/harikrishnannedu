﻿using HostedcheckoutMPGS.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HostedcheckoutMPGS.Controllers
{
    public class HomeController : Controller
    {

        private readonly string username;
        private readonly string password;
        private readonly string gatewayUrl;
        private readonly string merchantNumber;
        private readonly string versionNumber;
        private readonly string currency;
        private readonly int uniqRef;
        private readonly int amount;
        JObject json;

        public HomeController()
        {
            gatewayUrl = "https://test-adcb.mtf.gateway.mastercard.com/";
            username = "merchant.TEST120800000022";
            password = "067b275c4037865b6c19afd47e50cf73";
            versionNumber = "61";
            merchantNumber = "TEST120800000022";
            currency = "AED";
            uniqRef = 21050;
            amount = 53;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult CreateSession()
        {
            if (TempData["shortMessage"] != null)
                ViewBag.Message = TempData["shortMessage"].ToString();
            return View();
        }

        public IActionResult UpdateSession()
        {
            return View();
        }

        public IActionResult Authentication()
        {
            return View();
        }

        public IActionResult AuthPayer()
        {
            if (TempData["shortMessage"] != null)
                ViewBag.Message = TempData["shortMessage"].ToString();
            return View();
        }

        public IActionResult Pay()
        {

            HttpContext.Session.TryGetValue("sessionId", out byte[] sessionIdByte);
            var sessionId = SessionClass.ConvertToString(sessionIdByte);
            TempData["sessionId"] = sessionId;
            if (TempData["sessionId"] != null)
                ViewBag.sessionId = TempData["sessionId"].ToString();

            if (TempData["shortMessage"] != null)
                ViewBag.Message = TempData["shortMessage"].ToString();
            return View();
        }

        public async Task<IActionResult> PostSession()
        {
            var sessionId = "";


            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
                    System.Text.ASCIIEncoding.ASCII.GetBytes(
                    $"{username}:{password}")));
                var str = JObject.Parse(createInputJson());
                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/session", httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                json = JObject.Parse(response1.Result);
                sessionId = json.GetValue("session").SelectToken("id").ToString();
                HttpContext.Session.Set("sessionId", SessionClass.ConvertToBytes(sessionId));
            }

            TempData["shortMessage"] = json.ToString();
            return RedirectToAction("CreateSession");
        }

        private string createInputJson()
        {
            var cardDetails = "{\"apiOperation\":\"CREATE_CHECKOUT_SESSION\",\"interaction\":{\"operation\":\"PURCHASE\",\"returnUrl\":\"https://webhook.site/f3e89f54-c7dc-48f7-bfe9-62b8d07cec03?\"}," +
            "\"order\":{\"description\":\"TESTOKEN\",\"id\":" + uniqRef + ",\"reference\":" + uniqRef + ",\"amount\":\"" + amount + "\",\"currency\":\"" + currency + "\"}}";
            JObject jObject = JObject.Parse(cardDetails.ToString());
            return jObject.ToString();
        }

        public async Task<IActionResult> AuthPay()
        {
            JObject jsonObj;

            HttpContext.Session.TryGetValue("orderId", out byte[] sessionOrderByte);
            var orderId = SessionClass.ConvertToString(sessionOrderByte);
            HttpContext.Session.TryGetValue("tranId", out byte[] sessionTranByte);
            var tranId = SessionClass.ConvertToString(sessionTranByte);
            HttpContext.Session.TryGetValue("sessionId", out byte[] sessionIdByte);
            var sessionId = SessionClass.ConvertToString(sessionIdByte);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
            System.Text.ASCIIEncoding.ASCII.GetBytes(
               $"{username}:{password}")));

                var str = JObject.Parse(AuthPayerDetails(sessionId));

                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PutAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/order/" + orderId + "/transaction/" + tranId, httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                //resComplete = "{\"apiVersion\":\"49\",\"gatewayResponse\":#gatewayJson#}";
                //resComplete = resComplete.Replace("#gatewayJson#", response1.Result);
                jsonObj = JObject.Parse(response1.Result);
            }
            //TempData["shortMessage"] = jsonObj.ToString();
            return Ok(jsonObj.ToString());
        }

        public async Task<IActionResult> PayRequest()
        {
            JObject jsonObj;
            byte[] sessionOrderByte;
            byte[] sessionTranByte;
            byte[] sessionIdByte;
            HttpContext.Session.TryGetValue("orderId", out sessionOrderByte);
            var orderId = SessionClass.ConvertToString(sessionOrderByte);
            HttpContext.Session.TryGetValue("tranId", out sessionTranByte);
            var tranId = SessionClass.ConvertToString(sessionTranByte);
            HttpContext.Session.TryGetValue("sessionId", out sessionIdByte);
            var sessionId = SessionClass.ConvertToString(sessionIdByte);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
                System.Text.ASCIIEncoding.ASCII.GetBytes(
                $"{username}:{password}")));
                var str = JObject.Parse(PayDetails(sessionId, tranId, orderId));
                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PutAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/order/" + orderId + "/transaction/" + uniqRef, httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                jsonObj = JObject.Parse(response1.Result);
                //resComplete = "{\"apiVersion\":\"" + versionNumber + "\",\"gatewayResponse\":#gatewayJson#}";
                //resComplete = resComplete.Replace("#gatewayJson#", response1.Result);
            }
            TempData["shortMessage"] = jsonObj.ToString();
            return RedirectToAction("Pay");
        }

        private string AuthPayerDetails(string sessionId)
        {
            var AuthPayerDetails = "{\"authentication\":{\"redirectResponseUrl\":\"http://localhost:8080/MPGS/L/res.php\"},\"correlationId\":\"test\"," +
  "\"device\": {\"browser\": \"MOZILLA\",\"browserDetails\": {\"3DSecureChallengeWindowSize\": \"FULL_SCREEN\",\"acceptHeaders\": \"application/json\"," +
      "\"colorDepth\": 24,\"javaEnabled\": true,\"language\": \"en-US\",\"screenHeight\": 640, \"screenWidth\": 480,\"timeZone\": 273},\"ipAddress\": \"127.0.0.1\"}," +
   "\"order\":{\"amount\":\"100\",\"currency\":\"" + currency + "\"},\"session\": {\"id\": \"" + sessionId + "\",},\"apiOperation\": \"AUTHENTICATE_PAYER\"}";
            JObject jObject = JObject.Parse(AuthPayerDetails.ToString());
            return jObject.ToString();
        }

        private string PayDetails(string sessionId, string tranId, string orderId)
        {
            var PayDetails = "{\"apiOperation\":\"PAY\",\"authentication\":{\"transactionId\":\"" + tranId + "\"},\"order\":{\"amount\":\"100\",\"currency\":\"AED\",\"reference\":\"" + orderId + "\"}," +
      "\"sourceOfFunds\":{\"type\":\"CARD\"},\"session\":{\"id\":\"" + sessionId + "\"},\"transaction\":{\"reference\":\"" + uniqRef.ToString() + "\"} }";
            JObject jObject = JObject.Parse(PayDetails.ToString());
            return jObject.ToString();
        }
    }
}

