﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using HostedcheckoutMPGS.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace HostedcheckoutMPGS.Controllers
{
    public class PaymentController : Controller
    {
        private readonly string username;
        private readonly string password;
        private readonly string gatewayUrl;
        private readonly string merchantNumber;
        private readonly string versionNumber;
        private readonly string currency;

        public PaymentController()
        {
            gatewayUrl = "https://test-adcb.mtf.gateway.mastercard.com/";
            username = "merchant.TEST120800000022";
            password = "067b275c4037865b6c19afd47e50cf73";
            versionNumber = "61";
            merchantNumber = "TEST120800000022";
            currency = "AED";
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(IFormCollection collection)
        {
            Customer customerDetails = new Customer()
            {
                ExpMonth = collection["ExpMonth"],
                ExpYear = collection["ExpYear"],
            };

            JObject json = new JObject();
            string resComplete = "";

            byte[] sessionByte;
            HttpContext.Session.TryGetValue("sessionId", out sessionByte);

            var sessionId = SessionClass.ConvertToString(sessionByte);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
            System.Text.ASCIIEncoding.ASCII.GetBytes(
               $"{username}:{password}")));
                var str = JObject.Parse(createInputJson(customerDetails));
                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PutAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/session/" + sessionId, httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    json = JObject.Parse(response1.Result);
                    string merchantId = json.GetValue("merchant").ToString();
                    string sessioValue = (string)json.SelectToken("session.id");
                    string sessionVersion = (string)json.SelectToken("session.version");
                    resComplete = ("{\"merchant\":\"" + merchantId + "\",\"session\":\"" + sessioValue + "\",\"version\":\"" + sessionVersion + "\"}");
                }
            }

            ViewBag.Message = json.ToString();
            return View();
        }

        private string createInputJson(Customer customer)
        {
            var cardDetails = "{\"apiOperation\":\"CREATE_CHECKOUT_SESSION\",\"interaction\":{\"operation\":\"PURCHASE\",\"returnUrl\":\"http://localhost:8080/MPGS/L/r.php\"}," +
            "\"order\":{\"description\":\"TESTOKEN\",\"id\":1644999465,\"reference\":1644999465,\"amount\":\"500.00\",\"currency\":\"AED\"},\"customer\":{\"email\":\"rajeevan.pt@abzer.com\",\"firstName\":\"Rajeevan\",\"lastName\":\"PT\"}}";
            JObject jObject = JObject.Parse(cardDetails.ToString());
            return jObject.ToString();
        }

        public IActionResult Tran()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Tran(IFormCollection collection)
        {
            TranDetails tran = new TranDetails()
            {
                OrderId = collection["OrderId"],
                TranId = collection["TranId"]
            };

            HttpContext.Session.Set("orderId", SessionClass.ConvertToBytes(tran.OrderId));
            HttpContext.Session.Set("tranId", SessionClass.ConvertToBytes(tran.TranId));

            JObject jsonObj;

            byte[] sessionByte;
            HttpContext.Session.TryGetValue("sessionId", out sessionByte);

            var sessionId = SessionClass.ConvertToString(sessionByte);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
            System.Text.ASCIIEncoding.ASCII.GetBytes(
               $"{username}:{password}")));

                var str = JObject.Parse(CreateAuth(sessionId));

                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PutAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/order/" + tran.OrderId + "/transaction/" + tran.TranId, httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                jsonObj = JObject.Parse(response1.Result);
            }

            ViewBag.Message = jsonObj.ToString();
            return View();
        }

        private string CreateAuth(string sessionId)
        {

            var AuthDetails = "{ \"authentication\":{\"acceptVersions\":\"3DS1,3DS2\",\"channel\":\"PAYER_BROWSER\",\"purpose\":\"PAYMENT_TRANSACTION\"}," +
   "\"correlationId\":\"test\",\"order\":{\"currency\":\"" + currency + "\"},\"session\": {\"id\":\"" + sessionId + "\" },\"apiOperation\":\"INITIATE_AUTHENTICATION\"}";
            JObject jObject = JObject.Parse(AuthDetails.ToString());
            return jObject.ToString();
        }

        [HttpPost]
        public async Task<IActionResult> AuthPay(IFormCollection collection)
        {

            JObject jsonObj;

            byte[] sessionByte;
            HttpContext.Session.TryGetValue("sessionId", out sessionByte);
            var sessionId = SessionClass.ConvertToString(sessionByte);

            byte[] sessionByteOrder;
            HttpContext.Session.TryGetValue("OrderId", out sessionByteOrder);
            var OrderId = SessionClass.ConvertToString(sessionByteOrder);

            byte[] sessionByteTran;
            HttpContext.Session.TryGetValue("TranId", out sessionByteTran);
            var TranId = SessionClass.ConvertToString(sessionByteTran);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(gatewayUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(
            System.Text.ASCIIEncoding.ASCII.GetBytes(
               $"{username}:{password}")));

                var str = JObject.Parse(AuthPayerDetails(sessionId));

                StringContent httpContent = new StringContent(str.ToString(), UTF8Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PutAsync("api/rest/version/" + versionNumber + "/merchant/" + merchantNumber + "/order/" + OrderId + "/transaction/" + TranId, httpContent);
                var response1 = response.Content.ReadAsStringAsync();
                jsonObj = JObject.Parse(response1.Result);
            }
            ViewBag.Message = jsonObj.ToString();
            return View();
        }

        private string AuthPayerDetails(string sessionId)
        {
            var AuthPayerDetails = "{\"authentication\":{\"redirectResponseUrl\":\"http://localhost:8080/MPGS/L/res.php\"},\"correlationId\":\"test\"," +
  "\"device\": {\"browser\": \"MOZILLA\",\"browserDetails\": {\"3DSecureChallengeWindowSize\": \"FULL_SCREEN\",\"acceptHeaders\": \"application/json\"," +
      "\"colorDepth\": 24,\"javaEnabled\": true,\"language\": \"en-US\",\"screenHeight\": 640, \"screenWidth\": 480,\"timeZone\": 273},\"ipAddress\": \"127.0.0.1\"}," +
   "\"order\":{\"amount\":\"" + SessionClass.amount + "\",\"currency\":\"" + currency + "\"},\"session\": {\"id\": \"" + sessionId + "\",},\"apiOperation\": \"AUTHENTICATE_PAYER\"}";
            JObject jObject = JObject.Parse(AuthPayerDetails.ToString());
            return jObject.ToString();
        }
    }
}