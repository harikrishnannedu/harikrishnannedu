﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HostedcheckoutMPGS.Models
{
    public class Customer
    {
        public string firstname { get; set; }
        public string lastNmae { get; set; }
        public string email { get; set; }

        public string ExpMonth { get; set; }
        public string ExpYear { get; set; }

    }
}
